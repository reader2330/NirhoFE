package com.nirho.dao;

import com.nirho.model.PreguntaTema;

public interface PreguntaTemaDAO extends BaseDAO<PreguntaTema, Integer> {
	
}
