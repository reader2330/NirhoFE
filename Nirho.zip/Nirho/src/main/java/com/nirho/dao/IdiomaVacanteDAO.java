package com.nirho.dao;

import com.nirho.model.IdiomaVacante;

public interface IdiomaVacanteDAO extends BaseDAO<IdiomaVacante, Long> {
	
}
