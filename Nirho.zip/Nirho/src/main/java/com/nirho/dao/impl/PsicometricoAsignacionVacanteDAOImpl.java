package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.PsicometricoAsignacionVacanteDAO;
import com.nirho.model.PsicometricoAsignacionVacante;

@Repository
public class PsicometricoAsignacionVacanteDAOImpl extends AbstractDAO<PsicometricoAsignacionVacante, Long> implements PsicometricoAsignacionVacanteDAO {
	
}
