package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.IndicadoresNirhoDAO;
import com.nirho.model.IndicadoresNirho;

@Repository
public class IndicadoresNirhoDAOImpl extends AbstractDAO<IndicadoresNirho, Long> implements IndicadoresNirhoDAO {
	
}
