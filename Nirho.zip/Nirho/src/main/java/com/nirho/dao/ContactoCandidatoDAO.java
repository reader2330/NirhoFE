package com.nirho.dao;

import com.nirho.model.ContactoCandidato;

public interface ContactoCandidatoDAO extends BaseDAO<ContactoCandidato, Long> {
	
}
