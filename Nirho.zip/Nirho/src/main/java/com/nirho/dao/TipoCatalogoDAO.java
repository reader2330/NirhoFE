package com.nirho.dao;

import com.nirho.model.TipoCatalogo;

public interface TipoCatalogoDAO extends BaseDAO<TipoCatalogo, Long> {
	
}
