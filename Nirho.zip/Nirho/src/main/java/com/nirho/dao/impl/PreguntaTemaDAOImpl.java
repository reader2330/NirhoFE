package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.PreguntaTemaDAO;
import com.nirho.model.PreguntaTema;

@Repository
public class PreguntaTemaDAOImpl extends AbstractDAO<PreguntaTema, Integer> implements PreguntaTemaDAO {
	
}
