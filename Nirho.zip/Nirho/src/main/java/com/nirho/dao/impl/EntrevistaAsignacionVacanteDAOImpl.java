package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.EntrevistaAsignacionVacanteDAO;
import com.nirho.model.EntrevistaAsignacionVacante;

@Repository
public class EntrevistaAsignacionVacanteDAOImpl extends AbstractDAO<EntrevistaAsignacionVacante, Long> implements EntrevistaAsignacionVacanteDAO {
	
}
