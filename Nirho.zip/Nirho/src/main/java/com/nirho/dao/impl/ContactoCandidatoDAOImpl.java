package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ContactoCandidatoDAO;
import com.nirho.model.ContactoCandidato;

@Repository
public class ContactoCandidatoDAOImpl extends AbstractDAO<ContactoCandidato, Long> implements ContactoCandidatoDAO {
	
}
