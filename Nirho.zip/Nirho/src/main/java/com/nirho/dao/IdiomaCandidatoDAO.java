package com.nirho.dao;

import com.nirho.model.IdiomaCandidato;

public interface IdiomaCandidatoDAO extends BaseDAO<IdiomaCandidato, Long> {
	
}
