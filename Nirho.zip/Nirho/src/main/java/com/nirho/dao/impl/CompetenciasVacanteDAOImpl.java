package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.CompetenciasVacanteDAO;
import com.nirho.model.CompetenciasVacante;

@Repository
public class CompetenciasVacanteDAOImpl extends AbstractDAO<CompetenciasVacante, Long> implements CompetenciasVacanteDAO {
	
}
