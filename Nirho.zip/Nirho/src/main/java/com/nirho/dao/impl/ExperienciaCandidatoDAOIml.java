package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ExperienciaCandidatoDAO;
import com.nirho.model.ExperienciaCandidato;

@Repository
public class ExperienciaCandidatoDAOIml extends AbstractDAO<ExperienciaCandidato, Long> implements ExperienciaCandidatoDAO {
	
}
