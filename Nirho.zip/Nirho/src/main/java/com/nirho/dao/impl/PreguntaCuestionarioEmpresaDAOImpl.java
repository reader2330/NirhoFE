package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.PreguntaCuestionarioEmpresaDAO;
import com.nirho.model.PreguntaCuestionarioEmpresa;

@Repository
public class PreguntaCuestionarioEmpresaDAOImpl extends AbstractDAO<PreguntaCuestionarioEmpresa, Integer> implements PreguntaCuestionarioEmpresaDAO {
	
}
