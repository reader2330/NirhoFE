package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.IdiomaCandidatoDAO;
import com.nirho.model.IdiomaCandidato;

@Repository
public class IdiomaCandidatoDAOImpl extends AbstractDAO<IdiomaCandidato, Long> implements IdiomaCandidatoDAO {
	
}
