package com.nirho.dao;

import com.nirho.model.Modulo;

public interface ModuloDAO extends BaseDAO<Modulo, Integer> {
	
}
