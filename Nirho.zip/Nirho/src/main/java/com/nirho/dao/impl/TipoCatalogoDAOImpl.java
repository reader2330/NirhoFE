package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.TipoCatalogoDAO;
import com.nirho.model.TipoCatalogo;

@Repository
public class TipoCatalogoDAOImpl extends AbstractDAO<TipoCatalogo, Long> implements TipoCatalogoDAO {
	
}
