package com.nirho.dao;

import com.nirho.model.ConocimientoCandidato;

public interface ConocimientoCandidatoDAO extends BaseDAO<ConocimientoCandidato, Long> {
	
}
