package com.nirho.dao;

import com.nirho.model.CompetenciasVacante;

public interface CompetenciasVacanteDAO extends BaseDAO<CompetenciasVacante, Long> {
	
}
