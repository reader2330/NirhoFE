package com.nirho.dao;

import com.nirho.model.CaracteristicasCandidatoCv;

public interface CaracteristicasCandidatoCvDAO extends BaseDAO<CaracteristicasCandidatoCv, Long> {
	
}
