package com.nirho.dao;

import com.nirho.model.CaracteristicasCandidatoVacante;

public interface CaracteristicasCandidatoVacanteDAO extends BaseDAO<CaracteristicasCandidatoVacante, Long> {
	
}
