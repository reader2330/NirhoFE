package com.nirho.dao;

import com.nirho.model.ExperienciaCandidato;

public interface ExperienciaCandidatoDAO extends BaseDAO<ExperienciaCandidato, Long> {
	
}
