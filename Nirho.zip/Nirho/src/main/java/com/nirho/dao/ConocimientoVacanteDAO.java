package com.nirho.dao;

import com.nirho.model.ConocimientoVacante;

public interface ConocimientoVacanteDAO extends BaseDAO<ConocimientoVacante, Long> {
	
}
