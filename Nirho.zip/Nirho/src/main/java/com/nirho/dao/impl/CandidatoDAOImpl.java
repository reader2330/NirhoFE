package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.CandidatoDAO;
import com.nirho.model.Candidato;

@Repository
public class CandidatoDAOImpl extends AbstractDAO<Candidato, Long> implements CandidatoDAO {
	
}
