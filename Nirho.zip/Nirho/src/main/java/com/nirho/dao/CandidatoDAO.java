package com.nirho.dao;

import com.nirho.model.Candidato;

public interface CandidatoDAO extends BaseDAO<Candidato, Long> {
	
}
