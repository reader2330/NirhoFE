package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ConocimientoVacanteDAO;
import com.nirho.model.ConocimientoVacante;

@Repository
public class ConocimientoVacanteDAOImpl extends AbstractDAO<ConocimientoVacante, Long> implements ConocimientoVacanteDAO {
	
}
