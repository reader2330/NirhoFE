package com.nirho.dao;

import com.nirho.model.Contacto;

public interface ContactoDAO extends BaseDAO<Contacto, Long> {
	
}
