package com.nirho.dao;

import com.nirho.model.PsicometricoAsignacionVacante;

public interface PsicometricoAsignacionVacanteDAO extends BaseDAO<PsicometricoAsignacionVacante, Long> {
	
}
