package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.IdiomaVacanteDAO;
import com.nirho.model.IdiomaVacante;

@Repository
public class IdiomaVacanteDAOImpl extends AbstractDAO<IdiomaVacante, Long> implements IdiomaVacanteDAO {
	
}
