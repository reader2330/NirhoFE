package com.nirho.dao;

import com.nirho.model.Vacante;

public interface VacanteDAO extends BaseDAO<Vacante, Long> {
	
}
