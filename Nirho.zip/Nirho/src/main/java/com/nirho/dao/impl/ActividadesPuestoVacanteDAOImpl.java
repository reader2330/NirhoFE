package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ActividadesPuestoVacanteDAO;
import com.nirho.model.ActividadesPuestoVacante;

@Repository
public class ActividadesPuestoVacanteDAOImpl extends AbstractDAO<ActividadesPuestoVacante, Long> implements ActividadesPuestoVacanteDAO {
	
}
