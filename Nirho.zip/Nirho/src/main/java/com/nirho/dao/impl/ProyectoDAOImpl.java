package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ProyectoDAO;
import com.nirho.model.Proyecto;

@Repository
public class ProyectoDAOImpl extends AbstractDAO<Proyecto, Integer> implements ProyectoDAO {
	
}
