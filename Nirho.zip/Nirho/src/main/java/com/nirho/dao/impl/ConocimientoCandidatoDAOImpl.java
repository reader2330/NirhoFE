package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ConocimientoCandidatoDAO;
import com.nirho.model.ConocimientoCandidato;

@Repository
public class ConocimientoCandidatoDAOImpl extends AbstractDAO<ConocimientoCandidato, Long> implements ConocimientoCandidatoDAO {
	
}
