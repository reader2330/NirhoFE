package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.CaracteristicasCandidatoVacanteDAO;
import com.nirho.model.CaracteristicasCandidatoVacante;

@Repository
public class CaracteristicasCandidatoVacanteDAOImpl extends AbstractDAO<CaracteristicasCandidatoVacante, Long> implements CaracteristicasCandidatoVacanteDAO {
	
}
