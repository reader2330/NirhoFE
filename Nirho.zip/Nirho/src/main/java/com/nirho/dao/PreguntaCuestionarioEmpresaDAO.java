package com.nirho.dao;

import com.nirho.model.PreguntaCuestionarioEmpresa;

public interface PreguntaCuestionarioEmpresaDAO extends BaseDAO<PreguntaCuestionarioEmpresa, Integer> {

}
