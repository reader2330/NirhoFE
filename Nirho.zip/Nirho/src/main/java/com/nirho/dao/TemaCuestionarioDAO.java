package com.nirho.dao;

import com.nirho.model.TemaCuestionario;

public interface TemaCuestionarioDAO extends BaseDAO<TemaCuestionario, Integer> {
	
}
