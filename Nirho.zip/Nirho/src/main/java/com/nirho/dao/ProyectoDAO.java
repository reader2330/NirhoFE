package com.nirho.dao;

import com.nirho.model.Proyecto;

public interface ProyectoDAO extends BaseDAO<Proyecto, Integer> {
	
}
