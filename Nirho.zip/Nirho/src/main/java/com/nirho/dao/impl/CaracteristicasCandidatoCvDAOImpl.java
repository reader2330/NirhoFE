package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.CaracteristicasCandidatoCvDAO;
import com.nirho.model.CaracteristicasCandidatoCv;

@Repository
public class CaracteristicasCandidatoCvDAOImpl extends AbstractDAO<CaracteristicasCandidatoCv, Long> implements CaracteristicasCandidatoCvDAO {
	
}
