package com.nirho.dao;

import com.nirho.model.AsignacionConsultorVacante;

public interface AsignacionConsultorVacanteDAO extends BaseDAO<AsignacionConsultorVacante, Long> {
	
}
