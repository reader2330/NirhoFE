package com.nirho.dao;

import com.nirho.model.IndicadoresNirho;

public interface IndicadoresNirhoDAO extends BaseDAO<IndicadoresNirho, Long> {
	
}
