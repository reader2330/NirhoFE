package com.nirho.dao;

import com.nirho.model.ActividadesPuestoVacante;

public interface ActividadesPuestoVacanteDAO extends BaseDAO<ActividadesPuestoVacante, Long> {
	
}
