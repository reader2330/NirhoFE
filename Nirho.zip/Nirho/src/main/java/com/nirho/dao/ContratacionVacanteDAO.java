package com.nirho.dao;

import com.nirho.model.ContratacionVacante;

public interface ContratacionVacanteDAO extends BaseDAO<ContratacionVacante, Long> {
	
}
