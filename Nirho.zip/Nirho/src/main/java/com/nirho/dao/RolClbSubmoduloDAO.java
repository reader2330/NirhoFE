package com.nirho.dao;

import com.nirho.model.RolClbSubmodulo;
import com.nirho.model.RolClbSubmoduloPK;

public interface RolClbSubmoduloDAO extends BaseDAO<RolClbSubmodulo, RolClbSubmoduloPK> {
	
}
