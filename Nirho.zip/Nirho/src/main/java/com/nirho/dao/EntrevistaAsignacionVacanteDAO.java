package com.nirho.dao;

import com.nirho.model.EntrevistaAsignacionVacante;

public interface EntrevistaAsignacionVacanteDAO extends BaseDAO<EntrevistaAsignacionVacante, Long> {
	
}
