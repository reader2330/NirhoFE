package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ContratacionVacanteDAO;
import com.nirho.model.ContratacionVacante;

@Repository
public class ContratacionVacanteDAOImpl extends AbstractDAO<ContratacionVacante, Long> implements ContratacionVacanteDAO {
	
}
