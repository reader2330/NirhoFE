package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.TemaCuestionarioDAO;
import com.nirho.model.TemaCuestionario;

@Repository
public class TemaCuestionarioDAOImpl extends AbstractDAO<TemaCuestionario, Integer> implements TemaCuestionarioDAO {
	
}
