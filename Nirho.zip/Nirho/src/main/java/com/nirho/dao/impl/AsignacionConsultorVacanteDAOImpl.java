package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.AsignacionConsultorVacanteDAO;
import com.nirho.model.AsignacionConsultorVacante;

@Repository
public class AsignacionConsultorVacanteDAOImpl extends AbstractDAO<AsignacionConsultorVacante, Long> implements AsignacionConsultorVacanteDAO {
	
}
