package com.nirho.dao.impl;

import org.springframework.stereotype.Repository;

import com.nirho.dao.ModuloDAO;
import com.nirho.model.Modulo;

@Repository
public class ModuloDAOImpl extends AbstractDAO<Modulo, Integer> implements ModuloDAO {
	
}
