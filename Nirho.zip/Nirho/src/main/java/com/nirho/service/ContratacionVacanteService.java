package com.nirho.service;

public interface ContratacionVacanteService {
	
}
