package com.nirho.service;

public interface ContactoCandidatoService {
	
}
