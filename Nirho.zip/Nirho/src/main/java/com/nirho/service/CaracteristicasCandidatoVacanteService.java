package com.nirho.service;

public interface CaracteristicasCandidatoVacanteService {
	
}
