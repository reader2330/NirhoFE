package com.nirho.service;

public interface IdiomaVacanteService {
	
}
