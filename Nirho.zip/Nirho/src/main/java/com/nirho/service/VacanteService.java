package com.nirho.service;

public interface VacanteService {
	
}
