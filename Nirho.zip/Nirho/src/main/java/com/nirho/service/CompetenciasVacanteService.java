package com.nirho.service;

public interface CompetenciasVacanteService {
	
}
