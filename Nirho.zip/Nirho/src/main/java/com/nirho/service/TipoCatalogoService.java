package com.nirho.service;

public interface TipoCatalogoService {
	
}
