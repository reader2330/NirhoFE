package com.nirho.constant;

public interface ProyectoConstants {
	Integer ESTATUS_CAPTURA = 1;
	Integer ESTATUS_ASIGNADO = 2;
	Integer ESTATUS_CONFIGURACION = 3;
	Integer ESTATUS_CARGA = 4;
	Integer ESTATUS_ENVIADO = 5;
	Integer ESTATUS_VIGENTE = 6;
	Integer ESTATUS_FINALIZADO = 7;
	Integer ESTTUS_RESULTADOS = 8;
}
