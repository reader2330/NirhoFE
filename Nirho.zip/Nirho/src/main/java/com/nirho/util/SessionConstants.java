package com.nirho.util;

public interface SessionConstants {
	String USUARIO_ATTRIBUTE = "usuario";
}
