package com.nirho.exception;

public class NirhoControllerException  extends Exception {
	private static final long serialVersionUID = 1L;
	public NirhoControllerException(String message){
		super(message);
	}
}