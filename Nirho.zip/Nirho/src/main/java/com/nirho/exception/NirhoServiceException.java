package com.nirho.exception;

public class NirhoServiceException extends Exception {
	private static final long serialVersionUID = 1L;
	public NirhoServiceException(String message){
		super(message);
	}
}
